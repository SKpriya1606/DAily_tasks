package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.AdminDao;
import com.example.demo.Admin;

@Service
public class AdminServiceImpl implements AdminService{

	@Autowired
	private AdminDao adminDao;
	
	@Override
	public boolean validateAdmin(Admin admin) {
		// TODO Auto-generated method stub
		adminDao.validateAdmin(admin);
		return true;
	}
}