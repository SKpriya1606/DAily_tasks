package com.example.demo;

import java.util.ArrayList;
import java.util.List;
//import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Component
@Controller
public class HoneyProductController {

	@Autowired
	HoneyDao honeyDao;

	@Autowired
	private HoneyProductServiceImpl honeyproductService;
	
	@GetMapping("/honeylist")
	 public String getAllHoney(ModelMap model) {
	  List<HoneyProduct> honeylist =honeyproductService.gethoneylist();
	  model.addAttribute("honeylist", honeylist);
	  return "honey_list";
	}

	 @GetMapping("/update4/{id}")
	 public String updatehoney(@PathVariable int id,ModelMap model) {
  
	  HoneyProduct honeyproduct = honeyproductService.findhoneyproductById(id);
	  model.addAttribute("honeyForm", honeyproduct);

	  return "honey_form";
	 }

	 @GetMapping("/add4")
	 public String addHoney(ModelMap model) {

	 HoneyProduct honeyproduct = new HoneyProduct();
	  model.addAttribute("honeyForm", honeyproduct);
	  return "honey_form";
	 }

	@PostMapping(value="/save4")
	 public String saveOrUpdate(@ModelAttribute("honeyForm") HoneyProduct honeyproduct,ModelMap model) {
	  if(honeyproduct.getId()!= null) {
		  honeyproductService.updatehoney(honeyproduct);
	  } 
	  else {
		  honeyproductService.addhoney(honeyproduct);
	  }
	  return "redirect:/honeylist";
	 }
	
	
	 @GetMapping("/delete4/{id}")
	 public String deletehoney(@PathVariable("id") int id) {
	  honeyproductService.deletehoney(id);
	  
	  return "redirect:/honeylist";
	 }

	@RequestMapping(value = "/HoneyProductListCustomer", method = RequestMethod.GET)
	public String HoneyProductCustomer(ModelMap model) {
		List<HoneyProduct> honeyproductCustomer = honeyDao.getHoneyProductCustomer();
		model.addAttribute("honeyproductListCustomer", honeyproductCustomer);
		return "honeyproduct";
	}
	
	@PostMapping("honeycart")
	public String afterupdate(@RequestParam int id, @RequestParam("cartItemQuantity") int cartItemQuantity,Model model,RedirectAttributes redirectAttributes)
	{
	
	int result= honeyDao.getId(id,cartItemQuantity);
	if(result==0)
	{
		redirectAttributes.addFlashAttribute("addCartStatus",false);
	}
	else {
		redirectAttributes.addFlashAttribute("addCartStatus",true);
	}
	return "redirect:/HoneyProductListCustomer";
}

//	@ModelAttribute("menuItemCategory")
//	public List<String> populateCategory() {
//		List<String> categoryList = new ArrayList<String>();
//		categoryList.add("Starters");
//		categoryList.add("Main Course");
//		categoryList.add("Dessert");
//		categoryList.add("Drinks");
//		return categoryList;
//	}

//	@RequestMapping(value = "/ShowEditMenuItem", method = RequestMethod.GET)
//	public String showEditMenuItem(@RequestParam int id, ModelMap model) {
//		MenuItem menuItem = menuItemDao.getMenuItem(id);
//		model.addAttribute("menuItem", menuItem);		
//		return "edit-menu-item";
//	}
	
//	@RequestMapping(value = "/EditMenuItem", method = RequestMethod.POST)
//	public String editMenuItem(@Valid @ModelAttribute("menuItem") MenuItem menuItem, BindingResult result, ModelMap model) {
//		if(result.hasErrors()) {
//			return "edit-menu-item";
//		}
//		int updateResult = menuItemDao.update(menuItem);
//		if(updateResult==0) {
//			model.addAttribute("editMenuItemStatus", false);
//		}else {
//			model.addAttribute("editMenuItemStatus", true);
//		}
//		return "edit-menu-item-status";
//	}

}
