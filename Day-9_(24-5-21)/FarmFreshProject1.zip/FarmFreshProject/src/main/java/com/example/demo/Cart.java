package com.example.demo;

public class Cart {
	private long cartItemId;
	private String cartItemName;
	private double cartItemPrice;
	private int cartItemQuantity;


	public Cart() {

	}

	public long getCartItemId() {
		return cartItemId;
	}

	public void setCartItemId(long cartItemId) {
		this.cartItemId = cartItemId;
	}

	public String getCartItemName() {
		return cartItemName;
	}

	public void setCartItemName(String cartItemName) {
		this.cartItemName = cartItemName;
	}

	public double getCartItemPrice() {
		return cartItemPrice;
	}

	public void setCartItemPrice(double cartItemPrice) {
		this.cartItemPrice = cartItemPrice;
	}
	public int getCartItemQuantity() {
		return cartItemQuantity;
	}

	public void setCartItemQuantity(int cartItemQuantity) {
		this.cartItemQuantity = cartItemQuantity;
	}

	@Override
	public String toString() {
		return String.format("Cart [cartItemId=%s, cartItemName=%s, cartItemPrice=%s]",
				cartItemId, cartItemName, cartItemPrice);
	}

}
