package com.example.demo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HerbProductServiceImpl implements HerbProductService {

	
	@Autowired
	private HerbProductDaoImpl herbsDao;
	
	@Override
	public void addherb(HerbProduct herbproduct) {
		// TODO Auto-generated method stub
		herbsDao.addherb(herbproduct);
	}
	@Override
	public List<HerbProduct> getherbslist() {
		// TODO Auto-generated method stub
		return herbsDao.getherbslist();
	}
	@Override
	public void  updateherb(HerbProduct herbproduct) {
		// TODO Auto-generated method stub
		herbsDao.updateherb(herbproduct);
	}
	@Override
	public HerbProduct findherbproductById(int id) {
		// TODO Auto-generated method stub
		return herbsDao.findherbproductById(id);
	}
	@Override
	public void deleteherb(int id) {
		// TODO Auto-generated method stub
		herbsDao.deleteherb(id);
	}

}

