package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


public class FruitProductDaoRowMapper  implements RowMapper<FruitProduct> {

	@Override
	public FruitProduct mapRow(ResultSet rs, int rowNum) throws SQLException {
		FruitProduct fruitproduct = new FruitProduct();
	fruitproduct.setId(rs.getInt(1));
	fruitproduct.setProductname(rs.getString(2));
	fruitproduct.setProductcost(rs.getDouble(3));
	//fruitproduct.setProductquantity(rs.getInt(4));
		
	return fruitproduct;
	}

}
