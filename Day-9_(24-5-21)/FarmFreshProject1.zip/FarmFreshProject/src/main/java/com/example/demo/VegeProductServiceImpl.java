package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VegeProductServiceImpl implements VegeProductService {

	
	@Autowired
	private VegetablesDaoImpl vegetablesDao;
	
	@Override
	public void addvegetable(VegeProduct vegeproduct) {
		// TODO Auto-generated method stub
		vegetablesDao.addvegetable(vegeproduct);
	}
	@Override
	public List<VegeProduct> getvegetableslist() {
		// TODO Auto-generated method stub
		return vegetablesDao.getvegetableslist();
	}
	@Override
	public void  updatevegetable(VegeProduct vegeproduct) {
		// TODO Auto-generated method stub
		vegetablesDao.updatevegetable(vegeproduct);
	}
	@Override
	public VegeProduct findvegeproductById(int id) {
		// TODO Auto-generated method stub
		return vegetablesDao.findvegeproductById(id);
	}
	@Override
	public void deletevegetable(int id) {
		// TODO Auto-generated method stub
		vegetablesDao.deletevegetable(id);
	}

}
