package com.example.demo;

import com.example.demo.HerbProduct;
import java.util.List;

public interface HerbProductService {

	public void addherb(HerbProduct herbproduct);
	List<HerbProduct> getherbslist();
	public void updateherb(HerbProduct herbproduct);
	public HerbProduct findherbproductById(int id);
	public void deleteherb(int id);
}
