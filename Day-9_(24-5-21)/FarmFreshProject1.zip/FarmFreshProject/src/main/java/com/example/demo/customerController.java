package com.example.demo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class customerController {
	
	@Autowired
	private CustomerDAO customerDAO;
	
	
	@GetMapping("/frontpage")
	public ModelAndView register1() {
		ModelAndView mv =new ModelAndView();
		mv.setViewName("frontpage");
		
		return mv;
	}	
	@PostMapping("/frontpage")
	public ModelAndView registerUserToDb1(Customer customer)
	{
		this.customerDAO.create(customer);
		ModelAndView mv =new ModelAndView();
		mv.setViewName("/login");
		
		return mv;
	}
	
	@GetMapping("/register")
	public ModelAndView register() {
		ModelAndView mv =new ModelAndView();
		mv.setViewName("register");
		
		return mv;
	}
	@PostMapping("/register")
	public ModelAndView registerUserToDb(Customer customer)
	{
		ModelAndView mv =new ModelAndView();
		try {
			boolean check = this.customerDAO.create(customer);
	
			if(check)
			{
				//System.out.println("home page");
				mv.setViewName("login");
			}else {
				
				mv.addObject("error","Already Registered");
			    mv.setViewName("register");
			}
		return mv;
		}
		catch(Exception e)
		{
			mv.addObject("error","Something Went Wrong");
			mv.setViewName("register");
		}
		return mv;
	}
	
	
	@GetMapping("/login")
	public ModelAndView login() {
		ModelAndView mv =new ModelAndView();
		mv.setViewName("login");
		
		return mv;
	}
	
	@PostMapping("/login")
	public ModelAndView logincheck1(Customer customer) {
		ModelAndView mv =new ModelAndView();
		//Customer customer = new Customer();
		//customer.setUsername(username);
		//customer.setPassword(password);
		try {
			boolean auth = this.customerDAO.logincheck(customer);
	
			if(auth)
			{
				//System.out.println("home page");
				mv.setViewName("home");
			}
			else 
			{
				mv.addObject("error","Invalid username or password");
			    mv.setViewName("login");
			}
		return mv;
		}
		catch(Exception e)
		{
			mv.addObject("error","Something Went Wrong");
			mv.setViewName("login");
		}
		return mv;
	}
	
	@GetMapping("/passchange")
	public ModelAndView reset() {
		ModelAndView mv =new ModelAndView();
		mv.setViewName("passchange");
		
		return mv;
	}
	@PostMapping("/passchange")
	public ModelAndView reset(Customer customer)
	{
		ModelAndView mv =new ModelAndView();
		try {
			boolean change = this.customerDAO.reset(customer);
	
			if(change)
			{
				//System.out.println("home page");
				mv.setViewName("login");
			}
			else {
				
				mv.addObject("error","Password not change");
			    mv.setViewName("passchange");
			}
		return mv;
		}
		catch(Exception e)
		{
			mv.addObject("error","Something Went Wrong");
			mv.setViewName("passchange");
		}
		return mv;
	}

	@GetMapping("/about")
	public ModelAndView about() {
		ModelAndView mv =new ModelAndView();
		mv.setViewName("about");
		
		return mv;
	}
	@GetMapping("/contact")
	public ModelAndView contact() {
		ModelAndView mv =new ModelAndView();
		mv.setViewName("contact");
		
		return mv;
	}
	@GetMapping("/home")
	public ModelAndView home() {
		ModelAndView mv =new ModelAndView();
		mv.setViewName("home");
		
		return mv;
	}
	
	//@GetMapping("/demo1")
	//public String demo1() {
		
		//return "register";

//}
}
