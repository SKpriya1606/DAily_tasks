package com.example.demo;

import org.springframework.stereotype.Component;

import com.example.demo.Admin;

@Component
public interface AdminDao {

	public boolean validateAdmin(Admin admin);

}
