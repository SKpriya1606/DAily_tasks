package com.example.demo;

import java.util.ArrayList;
import java.util.List;
//import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Component
@Controller
public class FruitProductController {

	@Autowired
	FruitsDao fruitsDao;

	@Autowired
	private FruitProductServiceImpl fruitproductService;
	
	@GetMapping("/fruitslist")
	 public String getAllFruits(ModelMap model) {
	  List<FruitProduct> fruitslist =fruitproductService.getfruitslist();
	  model.addAttribute("fruitslist", fruitslist);
	  return "fruits_list";
	}

	 @GetMapping("/update2/{id}")
	 public String updatefruits(@PathVariable int id,ModelMap model) {
  
	  FruitProduct fruitproduct = fruitproductService.findfruitproductById(id);
	  model.addAttribute("fruitForm", fruitproduct);

	  return "fruit_form";
	 }

	 @GetMapping("/add2")
	 public String addFruit(ModelMap model) {

	 FruitProduct fruitproduct = new FruitProduct();
	  model.addAttribute("fruitForm", fruitproduct);
	  return "fruit_form";
	 }

	@PostMapping(value="/save2")
	 public String saveOrUpdate(@ModelAttribute("fruitForm") FruitProduct fruitproduct,ModelMap model) {
	  if(fruitproduct.getId()!= null) {
		  fruitproductService.updatefruit(fruitproduct);
	  } 
	  else {
		  fruitproductService.addfruit(fruitproduct);
	  }
	  return "redirect:/fruitslist";
	 }
	
	
	 @GetMapping("/delete2/{id}")
	 public String deletefruit(@PathVariable("id") int id) {
	  fruitproductService.deletefruit(id);
	  
	  return "redirect:/fruitslist";
	 }

	@RequestMapping(value = "/FruitProductListCustomer", method = RequestMethod.GET)
	public String FruitProductCustomer(ModelMap model) {
		List<FruitProduct> fruitproductCustomer = fruitsDao.getFruitProductCustomer();
		model.addAttribute("fruitproductListCustomer", fruitproductCustomer);
		return "fruitproduct";
	}

	@PostMapping("fruitcart")
	
	public String afterupdate(@RequestParam int id, @RequestParam("cartItemQuantity") int cartItemQuantity,Model model,RedirectAttributes redirectAttributes)
	{
	
	int result= fruitsDao.getId(id,cartItemQuantity);
	if(result==0)
	{
		redirectAttributes.addFlashAttribute("addCartStatus",false);
	}
	else {
		redirectAttributes.addFlashAttribute("addCartStatus",true);
	}
	return "redirect:/FruitProductListCustomer";
}
}