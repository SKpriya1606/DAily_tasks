package com.example.demo;

import java.util.ArrayList;
import java.util.List;
//import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Component
@Controller
public class HerbProductController {

	@Autowired
	HerbsDao herbsDao;

	@Autowired
	private HerbProductServiceImpl herbproductService;
	
	@GetMapping("/herbslist")
	 public String getAllHerbs(ModelMap model) {
	  List<HerbProduct> herbslist =herbproductService.getherbslist();
	  model.addAttribute("herbslist", herbslist);
	  return "herbs_list";
	}

	 @GetMapping("/update3/{id}")
	 public String updateherbs(@PathVariable int id,ModelMap model) {
  
	  HerbProduct herbproduct = herbproductService.findherbproductById(id);
	  model.addAttribute("herbForm", herbproduct);

	  return "herb_form";
	 }

	 @GetMapping("/add3")
	 public String addHerb(ModelMap model) {

	 HerbProduct herbproduct = new HerbProduct();
	  model.addAttribute("herbForm", herbproduct);
	  return "herb_form";
	 }

	@PostMapping(value="/save3")
	 public String saveOrUpdate(@ModelAttribute("herbForm") HerbProduct herbproduct,ModelMap model) {
	  if(herbproduct.getId()!= null) {
		  herbproductService.updateherb(herbproduct);
	  } 
	  else {
		  herbproductService.addherb(herbproduct);
	  }
	  return "redirect:/herbslist";
	 }
	
	
	 @GetMapping("/delete3/{id}")
	 public String deleteherb(@PathVariable("id") int id) {
	  herbproductService.deleteherb(id);
	  
	  return "redirect:/herbslist";
	 }


	@RequestMapping(value = "/HerbProductListCustomer", method = RequestMethod.GET)
	public String HerbProductCustomer(ModelMap model) {
		List<HerbProduct> herbproductCustomer = herbsDao.getHerbProductCustomer();
		model.addAttribute("herbproductListCustomer", herbproductCustomer);
		return "herbproduct";
	}
	@PostMapping("herbcart")
	public String afterupdate(@RequestParam int id, @RequestParam("cartItemQuantity") int cartItemQuantity,Model model,RedirectAttributes redirectAttributes)
	{
	
	int result= herbsDao.getId(id,cartItemQuantity);
	if(result==0)
	{
		redirectAttributes.addFlashAttribute("addCartStatus",false);
	}
	else {
		redirectAttributes.addFlashAttribute("addCartStatus",true);
	}
	return "redirect:/HerbProductListCustomer";
	}
}

//	@ModelAttribute("menuItemCategory")
//	public List<String> populateCategory() {
//		List<String> categoryList = new ArrayList<String>();
//		categoryList.add("Starters");
//		categoryList.add("Main Course");
//		categoryList.add("Dessert");
//		categoryList.add("Drinks");
//		return categoryList;
//	}

//	@RequestMapping(value = "/ShowEditMenuItem", method = RequestMethod.GET)
//	public String showEditMenuItem(@RequestParam int id, ModelMap model) {
//		MenuItem menuItem = menuItemDao.getMenuItem(id);
//		model.addAttribute("menuItem", menuItem);		
//		return "edit-menu-item";
//	}
	
//	@RequestMapping(value = "/EditMenuItem", method = RequestMethod.POST)
//	public String editMenuItem(@Valid @ModelAttribute("menuItem") MenuItem menuItem, BindingResult result, ModelMap model) {
//		if(result.hasErrors()) {
//			return "edit-menu-item";
//		}
//		int updateResult = menuItemDao.update(menuItem);
//		if(updateResult==0) {
//			model.addAttribute("editMenuItemStatus", false);
//		}else {
//			model.addAttribute("editMenuItemStatus", true);
//		}
//		return "edit-menu-item-status";
//	}

