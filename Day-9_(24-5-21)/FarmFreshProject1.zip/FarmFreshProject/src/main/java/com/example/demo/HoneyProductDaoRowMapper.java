package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


public class HoneyProductDaoRowMapper  implements RowMapper<HoneyProduct> {

	@Override
	public HoneyProduct mapRow(ResultSet rs, int rowNum) throws SQLException {
		HoneyProduct honeyproduct = new HoneyProduct();
	honeyproduct.setId(rs.getInt(1));
		honeyproduct.setProductname(rs.getString(2));
		honeyproduct.setProductcost(rs.getDouble(3));
		//honeyproduct.setProductquantity(rs.getInt(3));
		
		return honeyproduct;
	}

}
