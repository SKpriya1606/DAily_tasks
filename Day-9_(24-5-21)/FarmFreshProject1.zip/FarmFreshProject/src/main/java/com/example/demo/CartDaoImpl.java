package com.example.demo;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class CartDaoImpl implements CartDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

//	@Override
//	public int Vegesave(int id) {
//		String queryVegeProduct = "select * from vegeproduct where id=?";
//		VegeProductDaoRowMapper rowMapper = new VegeProductDaoRowMapper();
//		VegeProduct vegeproduct = jdbcTemplate.queryForObject(queryVegeProduct, rowMapper, id);
//		String saveCartItem = "insert into cart (cartItem_name, cartItem_price,cartItem_quantity) values (?, ?, ?);";
//		int result = jdbcTemplate.update(saveCartItem, vegeproduct.getProductname(), vegeproduct.getProductcost(), vegeproduct.getProductquantity());
//		return result;
//	}
//	
//	@Override
//	public int Fruitsave(int id) {
//		String queryFruitProduct = "select * from fruitproduct where id=?";
//		FruitProductDaoRowMapper rowMapper = new FruitProductDaoRowMapper();
//		FruitProduct fruitproduct = jdbcTemplate.queryForObject(queryFruitProduct, rowMapper, id);
//		String saveCartItem = "insert into cart (cartItem_name, cartItem_price,cartItem_quantity) values (?, ?, ?);";
//		int result = jdbcTemplate.update(saveCartItem, fruitproduct.getProductname(), fruitproduct.getProductcost(), fruitproduct.getProductquantity());
//		return result;
//	}
//	@Override
//	public int Herbsave(int id) {
//		String queryHerbProduct = "select * from herbproduct where id=?";
//		HerbProductDaoRowMapper rowMapper = new HerbProductDaoRowMapper();
//		HerbProduct herbproduct = jdbcTemplate.queryForObject(queryHerbProduct, rowMapper, id);
//		String saveCartItem = "insert into cart (cartItem_name, cartItem_price,cartItem_quantity) values (?, ?, ?);";
//		int result = jdbcTemplate.update(saveCartItem, herbproduct.getProductname(), herbproduct.getProductcost(), herbproduct.getProductquantity());
//		return result;
//	}
//	@Override
//	public int Honeysave(int id) {
//		String queryHoneyProduct = "select * from honeyproduct where id=?";
//		HoneyProductDaoRowMapper rowMapper = new HoneyProductDaoRowMapper();
//		HoneyProduct honeyproduct = jdbcTemplate.queryForObject(queryHoneyProduct, rowMapper, id);
//		String saveCartItem = "insert into cart (cartItem_name, cartItem_price,cartItem_quantity) values (?, ?, ?);";
//		int result = jdbcTemplate.update(saveCartItem, honeyproduct.getProductname(), honeyproduct.getProductcost(), honeyproduct.getProductquantity());
//		return result;
//	}

	@Override
	public List<Cart> getCartItems() {
		String queryCart = "select * from cart";
		CartDaoRowMapper rowMapper = new CartDaoRowMapper();
		List<Cart> cartItems = jdbcTemplate.query(queryCart, rowMapper);
		
		return cartItems;
	}

	@Override
	public int delete(int id) {
		String query = "delete from cart where cartItem_id=?;";
		int result = jdbcTemplate.update(query, id);
		
		return result;
	}

}

