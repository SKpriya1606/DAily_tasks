package com.example.demo;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Component
@Repository
@Transactional
public class FruitProductDaoImpl implements FruitsDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}


	@Override
	public FruitProduct findfruitproductById(int id) {
		// TODO Auto-generated method stub
			  String query = "SELECT * FROM fruitproduct WHERE id = ?";
			  FruitProductDaoRowMapper rowMapper = new FruitProductDaoRowMapper();
			 FruitProduct fruitproduct = jdbcTemplate.queryForObject(query, rowMapper, id);
			  
			  return fruitproduct;
	}
	@Override
	public void addfruit(FruitProduct fruitproduct) {
		// TODO Auto-generated method stub
		String sql="INSERT INTO fruitproduct(productname,productcost) VALUES(?,?)";
		jdbcTemplate.update(sql,fruitproduct.getProductname(),fruitproduct.getProductcost());
	}

	@Override
	public List<FruitProduct> getfruitslist() {
		// TODO Auto-generated method stub
		String sql="SELECT * FROM fruitproduct";
		FruitProductDaoRowMapper rowmapper=new FruitProductDaoRowMapper();
		List<FruitProduct> fruitslist=jdbcTemplate.query(sql,rowmapper);
		return fruitslist;
	}

	@Override
	public void updatefruit(FruitProduct fruitproduct) {
		// TODO Auto-generated method stub
		String sql="UPDATE fruitproduct SET productname=?,productcost=? WHERE id=?";
		jdbcTemplate.update(sql,fruitproduct.getProductname(),fruitproduct.getProductcost(),fruitproduct.getId());

	}


	@Override
	public void deletefruit(int id) {
		// TODO Auto-generated method stub
		String sql="DELETE FROM fruitproduct WHERE id=?";
		jdbcTemplate.update(sql, id);
	}

	@Override
	public List<FruitProduct> getFruitProductCustomer() {
		String sql = "select * from fruitproduct;";
		FruitProductDaoRowMapper rowmapper = new FruitProductDaoRowMapper();
		List<FruitProduct> FruitProductCustomer = jdbcTemplate.query(sql, rowmapper);
		return FruitProductCustomer;
	}

	@Override
	public int getId(int id,int productquantity) {
		String query = "select * from fruitproduct where id=?";
		FruitProductDaoRowMapper rowMapper = new FruitProductDaoRowMapper();
		FruitProduct fruitproduct = jdbcTemplate.queryForObject(query, rowMapper, id);
		String sql="INSERT INTO cart(cartItem_name,cartItem_price,cartItem_quantity)VALUES(?, ?, ?)";
		int result=jdbcTemplate.update(sql,fruitproduct.getProductname(),fruitproduct.getProductcost(),productquantity);
		return result;
	}

}

