package com.example.demo;

import java.util.List;
import org.springframework.stereotype.Component;

@Component
public interface VegetablesDAO {
	
	public void addvegetable(VegeProduct vegeProduct);
	public List<VegeProduct> getvegetableslist();
	public void updatevegetable(VegeProduct vegeproduct);
	public VegeProduct findvegeproductById(int id);
	public void deletevegetable(int id);
	List<VegeProduct> getVegeProductCustomer();
	int getId(int id,int productquantity);
	//int update(VegeProduct vegeproduct);
	
}
