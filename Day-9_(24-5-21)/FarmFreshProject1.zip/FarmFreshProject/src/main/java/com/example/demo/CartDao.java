package com.example.demo;

	import java.util.List;
	import org.springframework.stereotype.Component;
	@Component
	public interface CartDao {

//		int Vegesave(int id);
//		int Fruitsave(int id);
//		int Herbsave(int id);
//		int Honeysave(int id);
		int delete(int id);
		List<Cart> getCartItems(); 
		
	}

