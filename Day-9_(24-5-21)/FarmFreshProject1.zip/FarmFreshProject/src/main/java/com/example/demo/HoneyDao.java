package com.example.demo;

import java.util.List;



import org.springframework.stereotype.Component;

@Component
public interface HoneyDao {
	
	public void addhoney(HoneyProduct honeyProduct);
	public List<HoneyProduct> gethoneylist();
	public void updatehoney(HoneyProduct honeyproduct);
	public HoneyProduct findhoneyproductById(int id);
	public void deletehoney(int id);
	List<HoneyProduct> getHoneyProductCustomer();
	int getId(int id,int productquantity);
	
}
