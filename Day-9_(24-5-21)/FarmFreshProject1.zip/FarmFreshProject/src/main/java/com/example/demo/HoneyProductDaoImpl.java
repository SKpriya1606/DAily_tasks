package com.example.demo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Component
@Repository
@Transactional
public class HoneyProductDaoImpl implements HoneyDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public HoneyProduct findhoneyproductById(int id) {
		// TODO Auto-generated method stub
			  String query = "SELECT * FROM honeyproduct WHERE id = ?";
			  HoneyProductDaoRowMapper rowMapper = new HoneyProductDaoRowMapper();
			 HoneyProduct honeyproduct = jdbcTemplate.queryForObject(query, rowMapper, id);
			  
			  return honeyproduct;
	}
	@Override
	public void addhoney(HoneyProduct honeyproduct) {
		// TODO Auto-generated method stub
		String sql="INSERT INTO honeyproduct(productname,productcost) VALUES(?,?)";
		jdbcTemplate.update(sql,honeyproduct.getProductname(),honeyproduct.getProductcost());
	}

	@Override
	public List<HoneyProduct> gethoneylist() {
		// TODO Auto-generated method stub
		String sql="SELECT * FROM honeyproduct";
		HoneyProductDaoRowMapper rowmapper=new HoneyProductDaoRowMapper();
		List<HoneyProduct> honeylist=jdbcTemplate.query(sql,rowmapper);
		return honeylist;
	}

	@Override
	public void updatehoney(HoneyProduct honeyproduct) {
		// TODO Auto-generated method stub
		String sql="UPDATE honeyproduct SET productname=?,productcost=? WHERE id=?";
		jdbcTemplate.update(sql,honeyproduct.getProductname(),honeyproduct.getProductcost(),honeyproduct.getId());

	}


	@Override
	public void deletehoney(int id) {
		// TODO Auto-generated method stub
		String sql="DELETE FROM honeyproduct WHERE id=?";
		jdbcTemplate.update(sql, id);
	}


	@Override
	public List<HoneyProduct> getHoneyProductCustomer() {
		String sql = "select * from honeyproduct;";
		HoneyProductDaoRowMapper rowmapper = new HoneyProductDaoRowMapper();
		List<HoneyProduct> HoneyProductCustomer = jdbcTemplate.query(sql, rowmapper);
		return HoneyProductCustomer;
	}

	@Override
	public int getId(int id,int productquantity) {
		String query = "select * from honeyproduct where id=?";
		HoneyProductDaoRowMapper rowMapper = new HoneyProductDaoRowMapper();
		HoneyProduct honeyproduct = jdbcTemplate.queryForObject(query, rowMapper, id);
		String sql="INSERT INTO cart(cartItem_name,cartItem_price,cartItem_quantity)VALUES(?, ?, ?)";
		int result=jdbcTemplate.update(sql,honeyproduct.getProductname(),honeyproduct.getProductcost(),productquantity);
		return result;
	}


}

