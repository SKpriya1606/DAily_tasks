package com.example.demo;

import com.example.demo.FruitProduct;
import java.util.List;

public interface FruitProductService {

	public void addfruit(FruitProduct fruitproduct);
	List<FruitProduct> getfruitslist();
	public void updatefruit(FruitProduct fruitproduct);
	public FruitProduct findfruitproductById(int id);
	public void deletefruit(int id);
}


