package com.example.demo;

import java.util.List;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Component
@Repository
@Transactional
public class VegetablesDaoImpl implements VegetablesDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public VegeProduct findvegeproductById(int id) {
		// TODO Auto-generated method stub
			  String query = "SELECT * FROM vegeproduct WHERE id = ?";
			  VegeProductDaoRowMapper rowMapper = new VegeProductDaoRowMapper();
			 VegeProduct vegeproduct = jdbcTemplate.queryForObject(query, rowMapper, id);
			  
			  return vegeproduct;
	}
	@Override
	public void addvegetable(VegeProduct vegeproduct) {
		// TODO Auto-generated method stub
		String sql="INSERT INTO vegeproduct(productname,productcost) VALUES(?,?)";
		jdbcTemplate.update(sql,vegeproduct.getProductname(),vegeproduct.getProductcost());
	}

	@Override
	public List<VegeProduct> getvegetableslist() {
		// TODO Auto-generated method stub
		String sql="SELECT * FROM vegeproduct";
		VegeProductDaoRowMapper rowmapper=new VegeProductDaoRowMapper();
		List<VegeProduct> vegetableslist=jdbcTemplate.query(sql,rowmapper);
		return vegetableslist;
	}

	@Override
	public void updatevegetable(VegeProduct vegeproduct) {
		// TODO Auto-generated method stub
		String sql="UPDATE vegeproduct SET productname=?,productcost=? WHERE id=?";
		jdbcTemplate.update(sql,vegeproduct.getProductname(),vegeproduct.getProductcost(),vegeproduct.getId());

	}


	@Override
	public void deletevegetable(int id) {
		// TODO Auto-generated method stub
		String sql="DELETE FROM vegeproduct WHERE id=?";
		jdbcTemplate.update(sql, id);
	}
	
	
	@Override
	public List<VegeProduct> getVegeProductCustomer() {
		String sql = "select * from vegeproduct;";
		VegeProductDaoRowMapper rowmapper = new VegeProductDaoRowMapper();
		List<VegeProduct> vegeproductCustomer = jdbcTemplate.query(sql, rowmapper);
		
		return vegeproductCustomer;
	}

	@Override
	public int getId(int id,int productquantity) {
		String query = "select * from vegeproduct where id=?";
		VegeProductDaoRowMapper rowMapper = new VegeProductDaoRowMapper();
		VegeProduct vegeproduct = jdbcTemplate.queryForObject(query, rowMapper, id);
		String sql="INSERT INTO cart(cartItem_name,cartItem_price,cartItem_quantity)VALUES(?, ?, ?)";
		int result=jdbcTemplate.update(sql,vegeproduct.getProductname(),vegeproduct.getProductcost(),productquantity);
		
		return result;
	}

}

