package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


public class HerbProductDaoRowMapper  implements RowMapper<HerbProduct> {

	@Override
	public HerbProduct mapRow(ResultSet rs, int rowNum) throws SQLException {
		HerbProduct herbproduct = new HerbProduct();
	herbproduct.setId(rs.getInt(1));
		herbproduct.setProductname(rs.getString(2));
		herbproduct.setProductcost(rs.getDouble(3));
		herbproduct.setProductquantity(rs.getInt(3));
		
		return herbproduct;
	}

}
