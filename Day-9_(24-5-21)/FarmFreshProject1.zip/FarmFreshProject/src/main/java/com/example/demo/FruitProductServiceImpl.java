package com.example.demo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FruitProductServiceImpl implements FruitProductService {

	
	@Autowired
	private FruitProductDaoImpl fruitsDao;
	
	@Override
	public void addfruit(FruitProduct fruitproduct) {
		// TODO Auto-generated method stub
		fruitsDao.addfruit(fruitproduct);
	}
	@Override
	public List<FruitProduct> getfruitslist() {
		// TODO Auto-generated method stub
		return fruitsDao.getfruitslist();
	}
	@Override
	public void  updatefruit(FruitProduct fruitproduct) {
		// TODO Auto-generated method stub
		fruitsDao.updatefruit(fruitproduct);
	}
	@Override
	public FruitProduct findfruitproductById(int id) {
		// TODO Auto-generated method stub
		return fruitsDao.findfruitproductById(id);
	}
	@Override
	public void deletefruit(int id) {
		// TODO Auto-generated method stub
		fruitsDao.deletefruit(id);
	}

}

