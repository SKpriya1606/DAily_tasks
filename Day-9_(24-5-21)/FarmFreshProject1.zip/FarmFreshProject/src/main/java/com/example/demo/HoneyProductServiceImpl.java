package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HoneyProductServiceImpl implements HoneyProductService {

	
	@Autowired
	private HoneyProductDaoImpl honeyDao;
	
	@Override
	public void addhoney(HoneyProduct honeyproduct) {
		// TODO Auto-generated method stub
		honeyDao.addhoney(honeyproduct);
	}
	@Override
	public List<HoneyProduct> gethoneylist() {
		// TODO Auto-generated method stub
		return honeyDao.gethoneylist();
	}
	@Override
	public void  updatehoney(HoneyProduct honeyproduct) {
		// TODO Auto-generated method stub
		honeyDao.updatehoney(honeyproduct);
	}
	@Override
	public HoneyProduct findhoneyproductById(int id) {
		// TODO Auto-generated method stub
		return honeyDao.findhoneyproductById(id);
	}
	@Override
	public void deletehoney(int id) {
		// TODO Auto-generated method stub
		honeyDao.deletehoney(id);
	}

}

