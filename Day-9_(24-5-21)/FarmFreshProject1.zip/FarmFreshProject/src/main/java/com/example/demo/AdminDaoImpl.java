package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import com.example.demo.Admin;

@Component
public class AdminDaoImpl implements AdminDao{

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public boolean validateAdmin(Admin admin) {
		// TODO Auto-generated method stub
		int s=0;
		String sql="SELECT COUNT(*) FROM admin WHERE username=? AND password=?";
		s=jdbcTemplate.queryForObject(sql,new Object[]{admin.getUsername(),admin.getPassword()},Integer.class);
		if(s == 0)
		{
			return false;
		}
		else
		{
		return true;
	}
}

}