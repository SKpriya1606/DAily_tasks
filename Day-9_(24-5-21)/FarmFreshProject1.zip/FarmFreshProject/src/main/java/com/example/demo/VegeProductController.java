package com.example.demo;

import java.util.ArrayList;
import java.util.List;
//import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Component
@Controller
public class VegeProductController {

	@Autowired
	VegetablesDAO vegetablesDAO;
	@Autowired
	private VegeProductServiceImpl vegeproductService;
	
	@GetMapping("/vegetableslist")
	 public String getAllVegetables(ModelMap model) {
	  List<VegeProduct> vegetableslist =vegeproductService.getvegetableslist();
	  model.addAttribute("vegetableslist", vegetableslist);
	  return "vegetables_list";
	}

	 @GetMapping("/update/{id}")
	 public String updatevegetable(@PathVariable int id,ModelMap model) {
  
	  VegeProduct vegeproduct = vegeproductService.findvegeproductById(id);
	  model.addAttribute("vegetableForm", vegeproduct);

	  return "vegetable_form";
	 }

	 @GetMapping("/add")
	 public String addVegetable(ModelMap model) {

	 VegeProduct vegeproduct = new VegeProduct();
	  model.addAttribute("vegetableForm", vegeproduct);
	  return "vegetable_form";
	 }

	@PostMapping(value="/save")
	 public String saveOrUpdate(@ModelAttribute("vegetableForm") VegeProduct vegeproduct,ModelMap model) {
	  if(vegeproduct.getId()!= null) {
		  vegeproductService.updatevegetable(vegeproduct);
	  } 
	  else {
		  vegeproductService.addvegetable(vegeproduct);
	  }
	  return "redirect:/vegetableslist";
	 }
	
	
	 @GetMapping("/delete/{id}")
	 public String deletevegetable(@PathVariable("id") int id) {
	  vegeproductService.deletevegetable(id);
	  
	  return "redirect:/vegetableslist";
	 }
	


	@RequestMapping(value = "/VegeProductListCustomer", method = RequestMethod.GET)
	public String VegeProductCustomer(ModelMap model) {
		List<VegeProduct> vegeproductCustomer = vegetablesDAO.getVegeProductCustomer();
		model.addAttribute("vegeproductListCustomer", vegeproductCustomer);
		
		return "vegeproduct";
	}
	@PostMapping("vegecart")
		public String afterupdate(@RequestParam int id, @RequestParam("cartItemQuantity") int cartItemQuantity,Model model,RedirectAttributes redirectAttributes)
		{
		int result= vegetablesDAO.getId(id,cartItemQuantity);
		if(result==0)
		{
			redirectAttributes.addFlashAttribute("addCartStatus",false);
		}
		else {
			redirectAttributes.addFlashAttribute("addCartStatus",true);
		}
		
		return "redirect:/VegeProductListCustomer";
	}

}
