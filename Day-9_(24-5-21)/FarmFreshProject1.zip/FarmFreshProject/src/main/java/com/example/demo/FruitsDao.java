package com.example.demo;

import java.util.List;
import org.springframework.stereotype.Component;

@Component
public interface FruitsDao {
	
	public void addfruit(FruitProduct fruitProduct);
	public List<FruitProduct> getfruitslist();
	public void updatefruit(FruitProduct fruitproduct);
	public FruitProduct findfruitproductById(int id);
	public void deletefruit(int id);
	List<FruitProduct> getFruitProductCustomer();
	int getId(int id,int productquantity);
	//int update(VegeProduct vegeproduct);
	
}
