package com.example.demo;

import org.springframework.stereotype.Component;
import com.example.demo.HoneyProduct;

@Component
public class HoneyProduct {
	private Integer id;
	private String productname;
	private double productcost;
	private int productquantity;

	public HoneyProduct() {

	}

	
	public HoneyProduct(Integer id, String productname, double productcost, int productquantity) {
		super();
		this.id = id;
		this.productname = productname;
		this.productcost = productcost;
		this.productquantity = productquantity;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public double getProductcost() {
		return productcost;
	}
	public void setProductcost(double productcost) {
		this.productcost = productcost;
	}
	public int getProductquantity() {
		return productquantity;
	}

	public void setProductquantity(int productquantity) {
		this.productquantity = productquantity;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HoneyProduct other = (HoneyProduct) obj;
		if (id != other.id)
			return false;
		return true;
	}


}
