package com.example.demo;


import com.example.demo.VegeProduct;
import java.util.List;



public interface VegeProductService {

	public void addvegetable(VegeProduct vegeproduct);
	List<VegeProduct> getvegetableslist();
	public void updatevegetable(VegeProduct vegeproduct);
	public VegeProduct findvegeproductById(int id);
	public void deletevegetable(int id);
}
