package com.example.demo;

import java.util.List;



import org.springframework.stereotype.Component;

@Component
public interface HerbsDao {
	
	public void addherb(HerbProduct herbProduct);
	public List<HerbProduct> getherbslist();
	public void updateherb(HerbProduct herbproduct);
	public HerbProduct findherbproductById(int id);
	public void deleteherb(int id);
	List<HerbProduct> getHerbProductCustomer();
	int getId(int id,int productquantity);
	
	
}
