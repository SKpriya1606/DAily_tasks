package com.example.demo;

import org.springframework.stereotype.Component;
import com.example.demo.VegeProduct;

@Component
public class VegeProduct {
	private Integer id;
	private String productname;
	private double productcost;
	
	public VegeProduct() {

	}
	public VegeProduct(Integer id, String productname, double productcost, int productquantity) {
		super();
		this.id = id;
		this.productname = productname;
		this.productcost = productcost;
		
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public double getProductcost() {
		return productcost;
	}
	public void setProductcost(double productcost) {
		this.productcost = productcost;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VegeProduct other = (VegeProduct) obj;
		if (id != other.id)
			return false;
		return true;
	}


}
