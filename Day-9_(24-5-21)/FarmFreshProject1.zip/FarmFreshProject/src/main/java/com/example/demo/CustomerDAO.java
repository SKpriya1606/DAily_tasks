package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.SQLExceptionSubclassTranslator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class CustomerDAO {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public boolean create(Customer customer)
	{
		int dd=0;
		String sql="SELECT COUNT(*) FROM customer WHERE username=? AND password=?";
		dd=jdbcTemplate.queryForObject(sql, new Object[] {customer.getUsername(), customer.getPassword()}, Integer.class); 
				if(dd==0)
       {
    	   String sql1 = "INSERT INTO CUSTOMER (firstname,lastname,username,password,contact,gender) VALUES (?, ?, ?, ?, ?, ?)";
    	   
    	   jdbcTemplate.update(sql1,customer.getFirstname(), customer.getLastname(), customer.getUsername(), customer.getPassword(), customer.getContact(), customer.getGender());
		return true;
       }
				else {
					return false;
				}
	}

	public boolean logincheck(Customer customer)
	{
		int d=0;
		String sql="SELECT COUNT(*) FROM customer WHERE username=? AND password=?";
		d=jdbcTemplate.queryForObject(sql, new Object[] {customer.getUsername(), customer.getPassword()}, Integer.class);
		if(d==0)
		{
			return false;
		}
		
		else {
			
	      return true;
	} 
}
	public boolean reset(Customer customer)
	{
		int n=0;
		String sql="SELECT COUNT(*) FROM customer WHERE username=? AND contact=?";
		n=jdbcTemplate.queryForObject(sql, new Object[] {customer.getUsername(), customer.getContact()}, Integer.class); 
				if(n==0)
       {
					//System.out.println("thappu");
					return false;
       }
				else {
					
    	   String sql1 = "UPDATE  customer SET  password=? WHERE username=? AND contact=?";
    	   
    	   jdbcTemplate.update(sql1, customer.getPassword(),customer.getUsername(), customer.getContact());
    	   return true;
		
	}
	
}
}
	
	class CustomerRowMapper implements RowMapper<Customer> {
		
		@Override
		public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
			
			Customer user= new Customer();
			user.setId(rs.getInt("id"));
			user.setFirstname(rs.getString("firstname"));
			user.setLastname(rs.getString("lastname"));
			user.setUsername(rs.getString("username"));
			user.setPassword(rs.getString("password"));
			user.setContact(rs.getString("contact"));
			user.setGender(rs.getString("gender"));
			return user;
			
				}
	}
	