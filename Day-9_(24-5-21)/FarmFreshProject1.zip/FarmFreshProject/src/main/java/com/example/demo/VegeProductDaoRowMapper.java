package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


public class VegeProductDaoRowMapper  implements RowMapper<VegeProduct> {

	@Override
	public VegeProduct mapRow(ResultSet rs, int rowNum) throws SQLException {
		VegeProduct vegeproduct = new VegeProduct();
	    vegeproduct.setId(rs.getInt(1));
		vegeproduct.setProductname(rs.getString(2));
		vegeproduct.setProductcost(rs.getDouble(3));
		
		return vegeproduct;
	}

}
