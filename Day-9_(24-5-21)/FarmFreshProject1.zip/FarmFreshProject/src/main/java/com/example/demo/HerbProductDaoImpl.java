package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Component
@Repository
@Transactional
public class HerbProductDaoImpl implements HerbsDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public HerbProduct findherbproductById(int id) {
		// TODO Auto-generated method stub
			  String query = "SELECT * FROM herbproduct WHERE id = ?";
			  HerbProductDaoRowMapper rowMapper = new HerbProductDaoRowMapper();
			 HerbProduct herbproduct = jdbcTemplate.queryForObject(query, rowMapper, id);
			  
			  return herbproduct;
	}
	@Override
	public void addherb(HerbProduct herbproduct) {
		// TODO Auto-generated method stub
		String sql="INSERT INTO herbproduct(productname,productcost) VALUES(?,?)";
		jdbcTemplate.update(sql,herbproduct.getProductname(),herbproduct.getProductcost());
	}

	@Override
	public List<HerbProduct> getherbslist() {
		// TODO Auto-generated method stub
		String sql="SELECT * FROM herbproduct";
		HerbProductDaoRowMapper rowmapper=new HerbProductDaoRowMapper();
		List<HerbProduct> herbslist=jdbcTemplate.query(sql,rowmapper);
		return herbslist;
	}

	@Override
	public void updateherb(HerbProduct herbproduct) {
		// TODO Auto-generated method stub
		String sql="UPDATE herbproduct SET productname=?,productcost=? WHERE id=?";
		jdbcTemplate.update(sql,herbproduct.getProductname(),herbproduct.getProductcost(),herbproduct.getId());

	}


	@Override
	public void deleteherb(int id) {
		// TODO Auto-generated method stub
		String sql="DELETE FROM herbproduct WHERE id=?";
		jdbcTemplate.update(sql, id);
	}

	@Override
	public List<HerbProduct> getHerbProductCustomer() {
		String sql = "select * from herbproduct;";
		HerbProductDaoRowMapper rowmapper = new HerbProductDaoRowMapper();
		List<HerbProduct> HerbProductCustomer = jdbcTemplate.query(sql, rowmapper);
		return HerbProductCustomer;
	}

	@Override
	public int getId(int id,int productquantity) {
		String query = "select * from herbproduct where id=?";
		HerbProductDaoRowMapper rowMapper = new HerbProductDaoRowMapper();
		HerbProduct herbproduct = jdbcTemplate.queryForObject(query, rowMapper, id);
		String sql="INSERT INTO cart(cartItem_name,cartItem_price,cartItem_quantity)VALUES(?, ?, ?)";
		int result=jdbcTemplate.update(sql,herbproduct.getProductname(),herbproduct.getProductcost(),productquantity);
		return result;
	}


}

