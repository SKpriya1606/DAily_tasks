package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.Admin;

import com.example.demo.AdminService;
//import com.truyum.model.MenuItem;

@Controller
public class AdminLoginController {

	@Autowired
	private AdminDao adminDao;
	
	@GetMapping("/adminlogin")
	public String adminlogin() {
		return "adminlogin";
	}
	@PostMapping("/adminlogin")
	public ModelAndView adminvalidate(Admin admin) {
		ModelAndView mv=new ModelAndView();
		try {
		boolean isAdmin=adminDao.validateAdmin(admin);
		
		if(isAdmin) {
			
		mv.setViewName("adminhomepage");
		}
		else {
			mv.addObject("error","Only Admin Can Login");
			mv.setViewName("adminlogin");
		}
		return mv;
		}
		catch(Exception e) {
			mv.addObject("error","Something went wrong");
			mv.setViewName("adminlogin");
			return mv;
		}
	}
	@GetMapping("/adminhomepage")
		public String adminhomepage() {
			return "adminhomepage";
		}
		}
	



