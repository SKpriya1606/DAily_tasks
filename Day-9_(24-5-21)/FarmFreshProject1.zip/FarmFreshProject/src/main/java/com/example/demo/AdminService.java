package com.example.demo;

import org.springframework.stereotype.Service;

import com.example.demo.Admin;

@Service
public interface AdminService {

	public boolean validateAdmin(Admin admin);
}