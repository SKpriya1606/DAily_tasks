package com.example.demo;

import com.example.demo.HoneyProduct;
import java.util.List;

public interface HoneyProductService {

	public void addhoney(HoneyProduct honeyproduct);
	List<HoneyProduct> gethoneylist();
	public void updatehoney(HoneyProduct honeyproduct);
	public HoneyProduct findhoneyproductById(int id);
	public void deletehoney(int id);
}
